const express = require("express");

const xlsxfile = require("read-excel-file/node");
const upload = require("express-fileupload");

const mongoose = require('mongoose');


const url = 'mongodb://localhost:27017/mydb'
mongoose.connect(url);

var conn = mongoose.connection;
const app = express();

conn.on('connected', function() {
    console.log('database is connected successfully');
});
conn.on('disconnected',function(){
    console.log('database is disconnected successfully');
})
conn.on('error', console.error.bind(console, 'connection error:'));
module.exports = conn;

app.use(upload());

app.get("/", (req, res) => {
	res.sendFile(__dirname + "/index.html");
});

app.post("/", (req, res) => {
	if (req.files) {
		var file = req.files.file;
		var filename = file.name;

		// let newArray = [];
		// let uniqueObject = {};
		// for(let i in file){

		// }
		file.mv("./upload/" + filename, (err) => {
			if (err) {
				res.send(err);
			} else {
				

                mongoose.connect(url, (err, db)=>{
                    if(err) throw err;
                    console.log("database created");
                    var newArray = [];
				    var uniqueObject = new Map();

                   
                    xlsxfile("./upload/" + filename).then((row) => {
                        
                        row.forEach((col) => {

                            let objemail = col[1];
                            
                            if (!uniqueObject.has(objemail) && col[0] && col[1]) {
                                let robj = {};
                                for(let i=0; i<row[0].length; i++){
                                    robj[row[0][i]] = col[i];
                                }
                                uniqueObject.set(objemail, col);
                                newArray.push(robj);
                            }
                        });
                        
                        
                    });
                    console.log("excel file read");
                    
                    });

				res.sendFile(__dirname + "/success.html");
				
			}
            // Write the connectivity with mongodb using excel variables here
		});
	}
});

app.listen(5001);